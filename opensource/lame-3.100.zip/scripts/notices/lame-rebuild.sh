#!/bin/sh
set -eu
# Run from the extracted archive; output must be outside the source tree.
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
: "${ANDROID_SDK_ROOT:?Set ANDROID_SDK_ROOT to your Android SDK}"
: "${OUT:?Set OUT to a fresh output directory}"
NDK="$ANDROID_SDK_ROOT/ndk/27.1.12297006"
CMAKE="$ANDROID_SDK_ROOT/cmake/3.22.1/bin/cmake"
NINJA="$ANDROID_SDK_ROOT/cmake/3.22.1/bin/ninja"
SRC="$ROOT/modules/compresser-audio-encoder/android/src/main/cpp"
ABI=${ABI:-arm64-v8a}
API=${API:-24}
mkdir -p "$OUT"
"$CMAKE" -S "$SRC" -B "$OUT" -G Ninja -DCMAKE_MAKE_PROGRAM="$NINJA" -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" -DANDROID_ABI="$ABI" -DANDROID_PLATFORM="android-$API" -DANDROID_SUPPORT_FLEXIBLE_PAGE_SIZES=ON -DCMAKE_BUILD_TYPE=Release
"$CMAKE" --build "$OUT" --target mp3lame compresser_lame_jni
READELF="$NDK/toolchains/llvm/prebuilt/darwin-x86_64/bin/llvm-readelf"
"$READELF" -d "$OUT/libmp3lame.so"
"$READELF" -d "$OUT/libcompresser_lame_jni.so"
"$READELF" --dyn-syms --wide "$OUT/libmp3lame.so"
