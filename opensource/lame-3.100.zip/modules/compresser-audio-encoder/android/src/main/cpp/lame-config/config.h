/*
 * config.h for building the unmodified libmp3lame sources of LAME 3.100 with
 * the Android NDK (clang, bionic), for every Android ABI.
 *
 * LAME normally generates this file with ./configure from config.h.in. This is
 * a hand-written equivalent of that generated file, so that no LAME source
 * file has to be edited. It is build configuration for LAME and travels with
 * the LAME sources.
 *
 * Deliberately NOT defined:
 *   HAVE_MPGLIB, DECODE_ON_THE_FLY  - encoder only, no MP3 decoder is built
 *   HAVE_NASM, HAVE_XMMINTRIN_H, MMX_choose_table - portable C paths only
 *   TAKEHIRO_IEEE754_HACK, USE_FAST_LOG - portable C paths only
 */
#ifndef LAME_CONFIG_H
#define LAME_CONFIG_H

#define STDC_HEADERS 1
#define HAVE_ERRNO_H 1
#define HAVE_FCNTL_H 1
#define HAVE_INTTYPES_H 1
#define HAVE_LIMITS_H 1
#define HAVE_MEMORY_H 1
#define HAVE_STDINT_H 1
#define HAVE_STDLIB_H 1
#define HAVE_STRING_H 1
#define HAVE_STRINGS_H 1
#define HAVE_STRTOL 1
#define HAVE_SYS_STAT_H 1
#define HAVE_SYS_TIME_H 1
#define HAVE_SYS_TYPES_H 1
#define HAVE_UNISTD_H 1

/* Fixed-width integers come from <stdint.h>. */
#include <stdint.h>
#define HAVE_INT8_T 1
#define HAVE_INT16_T 1
#define HAVE_INT32_T 1
#define HAVE_INT64_T 1
#define HAVE_UINT8_T 1
#define HAVE_UINT16_T 1
#define HAVE_UINT32_T 1
#define HAVE_UINT64_T 1

/* Same fallbacks as config.h.in: the C library does not provide these types. */
#ifndef HAVE_IEEE754_FLOAT32_T
typedef float ieee754_float32_t;
#endif
#ifndef HAVE_IEEE754_FLOAT64_T
typedef double ieee754_float64_t;
#endif
#ifndef HAVE_IEEE854_FLOAT80_T
typedef long double ieee854_float80_t;
#endif

#define PACKAGE "lame"
#define PACKAGE_NAME "lame"
#define PACKAGE_VERSION "3.100"
#define VERSION "3.100"

#endif /* LAME_CONFIG_H */
