/*
 * compresser_lame_jni.c - narrow JNI bridge between
 * expo.modules.compresseraudioencoder.LameNative and libmp3lame.
 *
 * Own code of the Compresser app. It contains no LAME source and no code from
 * TAndroidLame. It uses only functions declared in the public header lame.h
 * and links to libmp3lame as a separate shared library.
 *
 * Scope: constant-bitrate MP3 from interleaved 16-bit PCM, mono or stereo.
 * No decoding, no ID3 tags, no VBR, no Xing/Info header.
 */
#include <jni.h>
#include <stdint.h>
#include <stdlib.h>

#include "lame.h"

/*
 * lame.h: worst case output is 1.25 * samples_per_channel + 7200 bytes, counted
 * in samples LAME encodes. LAME may resample first and then encodes up to 1.4
 * times the frames it was given (see nativeOpen), so one call must come with
 * room for twice the frames passed in. A flush needs the 7200 bytes alone.
 */
#define FLUSH_MIN_BYTES 7200
#define ENCODE_BYTES_PER_FRAME 2

/* Lowest sample rate an MP3 stream can carry (MPEG-2.5). */
#define MIN_INPUT_SAMPLE_RATE 8000

/*
 * LAME's speed/quality switch, 0 (best, slowest) .. 9. LAME's own default for
 * constant bitrate is 3. 5 keeps the speed of the encoder this replaces: it
 * was the default of the builder in TAndroidLame@277c2ab4b0, which
 * react-native-compressor never overrode. Read from that source, not measured.
 */
#define ENCODER_QUALITY 5

#define ERR_BAD_ARGUMENT (-100)
#define ERR_PCM_TOO_SHORT (-101)
#define ERR_OUT_TOO_SMALL (-102)
#define ERR_NO_MEMORY (-103)

typedef struct {
    lame_global_flags *flags;
    int channels;
} encoder_t;

static encoder_t *from_handle(jlong handle) {
    return (encoder_t *) (intptr_t) handle;
}

/* Sample rates an MPEG-1/2/2.5 Layer III stream can carry. */
static int is_mp3_sample_rate(int rate) {
    switch (rate) {
        case 8000: case 11025: case 12000:
        case 16000: case 22050: case 24000:
        case 32000: case 44100: case 48000:
            return 1;
        default:
            return 0;
    }
}

JNIEXPORT jlong JNICALL
Java_expo_modules_compresseraudioencoder_LameNative_nativeOpen(
        JNIEnv *env, jclass clazz, jint sampleRate, jint channels, jint bitrateKbps) {
    (void) env;
    (void) clazz;
    /*
     * LAME resamples a source rate that MP3 cannot carry (output rate 0 below):
     * down to the rate its low-pass for the bitrate suggests, or, when the
     * source rate lies under that, up to the next MP3 rate. From 8 kHz on the
     * way up is by less than 1.4x and the caller sizes its output buffer for
     * it. Below 8 kHz the factor has no such limit, so that input is refused;
     * the caller keeps the original file.
     */
    if (sampleRate < MIN_INPUT_SAMPLE_RATE || channels < 1 || channels > 2 || bitrateKbps <= 0) return 0;

    encoder_t *encoder = (encoder_t *) calloc(1, sizeof(encoder_t));
    if (encoder == NULL) return 0;
    encoder->channels = channels;
    encoder->flags = lame_init();
    if (encoder->flags == NULL) {
        free(encoder);
        return 0;
    }

    /*
     * Output rate: keep the source rate when MP3 can carry it, otherwise 0,
     * which lets LAME pick a legal rate and resample. LAME itself moves the
     * bitrate to the nearest value that is legal for the chosen rate.
     */
    int ok = lame_set_in_samplerate(encoder->flags, sampleRate) == 0
          && lame_set_num_channels(encoder->flags, channels) == 0
          && lame_set_out_samplerate(encoder->flags, is_mp3_sample_rate(sampleRate) ? sampleRate : 0) == 0
          && lame_set_brate(encoder->flags, bitrateKbps) == 0
          && lame_set_quality(encoder->flags, ENCODER_QUALITY) == 0
          && lame_set_bWriteVbrTag(encoder->flags, 0) == 0
          && lame_init_params(encoder->flags) >= 0;
    if (!ok) {
        lame_close(encoder->flags);
        free(encoder);
        return 0;
    }
    return (jlong) (intptr_t) encoder;
}

JNIEXPORT jint JNICALL
Java_expo_modules_compresseraudioencoder_LameNative_nativeEncode(
        JNIEnv *env, jclass clazz, jlong handle, jshortArray pcm, jint frames, jbyteArray out) {
    (void) clazz;
    encoder_t *encoder = from_handle(handle);
    if (encoder == NULL || encoder->flags == NULL || pcm == NULL || out == NULL || frames <= 0) {
        return ERR_BAD_ARGUMENT;
    }

    jsize pcmLength = (*env)->GetArrayLength(env, pcm);
    jsize outLength = (*env)->GetArrayLength(env, out);
    if ((jlong) frames * encoder->channels > (jlong) pcmLength) return ERR_PCM_TOO_SHORT;
    if ((jlong) outLength < (jlong) frames * ENCODE_BYTES_PER_FRAME + FLUSH_MIN_BYTES) return ERR_OUT_TOO_SMALL;

    jshort *samples = (*env)->GetShortArrayElements(env, pcm, NULL);
    if (samples == NULL) return ERR_NO_MEMORY;
    jbyte *buffer = (*env)->GetByteArrayElements(env, out, NULL);
    if (buffer == NULL) {
        (*env)->ReleaseShortArrayElements(env, pcm, samples, JNI_ABORT);
        return ERR_NO_MEMORY;
    }

    int written;
    if (encoder->channels == 2) {
        written = lame_encode_buffer_interleaved(
                encoder->flags, (short int *) samples, (int) frames,
                (unsigned char *) buffer, (int) outLength);
    } else {
        /* Mono: LAME reads the left buffer only. */
        written = lame_encode_buffer(
                encoder->flags, (const short int *) samples, (const short int *) samples, (int) frames,
                (unsigned char *) buffer, (int) outLength);
    }

    (*env)->ReleaseByteArrayElements(env, out, buffer, written > 0 ? 0 : JNI_ABORT);
    (*env)->ReleaseShortArrayElements(env, pcm, samples, JNI_ABORT);
    return (jint) written;
}

JNIEXPORT jint JNICALL
Java_expo_modules_compresseraudioencoder_LameNative_nativeFlush(
        JNIEnv *env, jclass clazz, jlong handle, jbyteArray out) {
    (void) clazz;
    encoder_t *encoder = from_handle(handle);
    if (encoder == NULL || encoder->flags == NULL || out == NULL) return ERR_BAD_ARGUMENT;

    jsize outLength = (*env)->GetArrayLength(env, out);
    if (outLength < FLUSH_MIN_BYTES) return ERR_OUT_TOO_SMALL;

    jbyte *buffer = (*env)->GetByteArrayElements(env, out, NULL);
    if (buffer == NULL) return ERR_NO_MEMORY;
    int written = lame_encode_flush(encoder->flags, (unsigned char *) buffer, (int) outLength);
    (*env)->ReleaseByteArrayElements(env, out, buffer, written > 0 ? 0 : JNI_ABORT);
    return (jint) written;
}

JNIEXPORT void JNICALL
Java_expo_modules_compresseraudioencoder_LameNative_nativeClose(
        JNIEnv *env, jclass clazz, jlong handle) {
    (void) env;
    (void) clazz;
    encoder_t *encoder = from_handle(handle);
    if (encoder == NULL) return;
    if (encoder->flags != NULL) lame_close(encoder->flags);
    encoder->flags = NULL;
    free(encoder);
}

JNIEXPORT jstring JNICALL
Java_expo_modules_compresseraudioencoder_LameNative_nativeLameVersion(
        JNIEnv *env, jclass clazz) {
    (void) clazz;
    return (*env)->NewStringUTF(env, get_lame_version());
}
