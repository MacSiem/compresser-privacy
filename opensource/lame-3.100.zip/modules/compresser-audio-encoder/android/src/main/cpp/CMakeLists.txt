# compresser-audio-encoder, variant C: MP3 through libmp3lame.
#
# Two shared libraries on purpose:
#   libmp3lame.so            - LAME 3.100, built from the unmodified sources in
#                              lame-3.100/ (LGPL-2.0-or-later, see lame-3.100/COPYING)
#   libcompresser_lame_jni.so - the app's own JNI bridge, linked dynamically
# Keeping LAME in its own library is a technical separation. Whether it meets
# the LGPL obligations of a closed app is an open legal question, not answered here.
#
# NOT BUILT in the package that produced this file: NDK, CMake and Gradle were
# not run. Treat every line below as unverified until a real build passes.
cmake_minimum_required(VERSION 3.22.1)

project(compresser_audio_encoder C)

set(LAME_ROOT ${CMAKE_CURRENT_SOURCE_DIR}/lame-3.100)
set(LAME_LIB_DIR ${LAME_ROOT}/libmp3lame)

# Every .c file of libmp3lame except the x86-only vector/ and i386/ parts.
# mpglib_interface.c compiles to nothing because HAVE_MPGLIB is not defined.
add_library(mp3lame SHARED
    ${LAME_LIB_DIR}/VbrTag.c
    ${LAME_LIB_DIR}/bitstream.c
    ${LAME_LIB_DIR}/encoder.c
    ${LAME_LIB_DIR}/fft.c
    ${LAME_LIB_DIR}/gain_analysis.c
    ${LAME_LIB_DIR}/id3tag.c
    ${LAME_LIB_DIR}/lame.c
    ${LAME_LIB_DIR}/mpglib_interface.c
    ${LAME_LIB_DIR}/newmdct.c
    ${LAME_LIB_DIR}/presets.c
    ${LAME_LIB_DIR}/psymodel.c
    ${LAME_LIB_DIR}/quantize.c
    ${LAME_LIB_DIR}/quantize_pvt.c
    ${LAME_LIB_DIR}/reservoir.c
    ${LAME_LIB_DIR}/set_get.c
    ${LAME_LIB_DIR}/tables.c
    ${LAME_LIB_DIR}/takehiro.c
    ${LAME_LIB_DIR}/util.c
    ${LAME_LIB_DIR}/vbrquantize.c
    ${LAME_LIB_DIR}/version.c
)
target_include_directories(mp3lame
    PUBLIC ${LAME_ROOT}/include
    PRIVATE ${LAME_LIB_DIR} ${CMAKE_CURRENT_SOURCE_DIR}/lame-config
)
# NDEBUG and -O2 in every build type: a debug build of the app would otherwise
# run LAME unoptimised with assert() active, several times slower (the JS side
# gives up after 90 s) and able to abort the process.
target_compile_definitions(mp3lame PRIVATE HAVE_CONFIG_H NDEBUG)
# Upstream code as released: its warnings are not ours to fix here.
target_compile_options(mp3lame PRIVATE -w -O2)
target_link_libraries(mp3lame PRIVATE m)

add_library(compresser_lame_jni SHARED compresser_lame_jni.c)
target_compile_options(compresser_lame_jni PRIVATE -Wall -Wextra)
target_link_libraries(compresser_lame_jni PRIVATE mp3lame)
