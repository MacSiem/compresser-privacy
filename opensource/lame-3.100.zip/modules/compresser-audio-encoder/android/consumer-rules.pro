# The JNI bridge (src/main/cpp/compresser_lame_jni.c) finds these methods by
# their exact names. Keep them whatever shrinker configuration the app uses.
-keepclasseswithmembernames class expo.modules.compresseraudioencoder.LameNative {
    native <methods>;
}
